package com.hashedin.hu22.service;

import com.hashedin.hu22.entities.Movie;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MovieService {

    Movie saveMovie(Movie movie);
    List<Movie> getAllMovies();
    Movie getMovieByName(String movieName);
    Movie updateMovie(Movie movie, String movieName);
}
