package com.hashedin.hu22.service.impl;

import com.hashedin.hu22.controllers.status;
import com.hashedin.hu22.entities.User;
import com.hashedin.hu22.exception.ResourceNotFoundException;
import com.hashedin.hu22.repositories.UserRepository;
import com.hashedin.hu22.service.UserService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserByMobile(String mobile) {
        return userRepository.findById(mobile).orElseThrow(()->new ResourceNotFoundException("User","mobile",mobile));
    }

    @Override
    public User updateUser(User user, String mobile) {

        //check if user is present in database or not
        User existingUser = userRepository.findById(mobile).orElseThrow(
                ()->new ResourceNotFoundException("User","mobile",mobile));

        existingUser.setDob(user.getDob());
        existingUser.setFname(user.getFname());
        existingUser.setLname(user.getLname());
        existingUser.setEmail(user.getEmail());
        existingUser.setPrefLocation(user.getPrefLocation());
        existingUser.setPrefGenre(user.getPrefGenre());

        //save to database
        return userRepository.save(existingUser);
    }

    @Override
    public status userLogin(User user) {
        List<User> allUsers = userRepository.findAll();
        for(User other:allUsers) {
            if(other.getMobile().equals(user.getMobile()) && other.getDob().equals(user.getDob())) {
                return status.Success;
            }
        }
        return status.Failure;
    }
}
