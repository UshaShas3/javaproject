package com.hashedin.hu22.controllers;

import com.hashedin.hu22.entities.Movie;
import com.hashedin.hu22.entities.User;
import com.hashedin.hu22.service.MovieService;
import com.hashedin.hu22.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/movie/")
public class MovieController {

    private MovieService movieService;

    public MovieController(MovieService movieService) {
        this.movieService = movieService;
    }

    //create movies
    @PostMapping()
    public ResponseEntity<Movie> saveMovie(@RequestBody Movie movie) {
        return new ResponseEntity<Movie>(movieService.saveMovie(movie), HttpStatus.CREATED);
    }

    //GET all movies
    @GetMapping
    public List<Movie> getAllMovies() {
        return movieService.getAllMovies();
    }

    //GET by ID - movie name
    @GetMapping("{movieName}")
    public ResponseEntity<Movie> getMovieByName(@PathVariable("movieName") String movieName) {
        return new ResponseEntity<Movie>(movieService.getMovieByName(movieName),HttpStatus.OK);
    }

    //Update movie
    @PutMapping("{movieName}")
    public ResponseEntity<Movie> updateMovie(@PathVariable("movieName") String movieName,@RequestBody Movie movie) {
        return new ResponseEntity<Movie>(movieService.updateMovie(movie,movieName),HttpStatus.OK);
    }
}
