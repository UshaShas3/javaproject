package com.hashedin.hu22.controllers;

import com.hashedin.hu22.entities.User;
import com.hashedin.hu22.repositories.UserRepository;
import com.hashedin.hu22.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user/")
public class UserController {

    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    //create user
    @PostMapping()
    public ResponseEntity<User> saveUser(@RequestBody User user) {
        user.setRole("Customer");
        return new ResponseEntity<User>(userService.saveUser(user), HttpStatus.CREATED);
    }

    //GET all user
    @GetMapping
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    //Login
    @RequestMapping("/login")
    public status userLogin(@RequestBody User user) {
        return userService.userLogin(user);
    }

    //GET by ID user
    @GetMapping("{mobile}")
    public ResponseEntity<User> getUserById(@PathVariable("mobile") String mobile) {
        return new ResponseEntity<User>(userService.getUserByMobile(mobile),HttpStatus.OK);
    }

    //Update user
    @PutMapping("{mobile}")
    public ResponseEntity<User> updateUser(@PathVariable("mobile") String mobile,@RequestBody User user) {
        return new ResponseEntity<User>(userService.updateUser(user,mobile),HttpStatus.OK);
    }

}
