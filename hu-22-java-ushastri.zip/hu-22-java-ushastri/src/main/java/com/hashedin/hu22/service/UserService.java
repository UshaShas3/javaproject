package com.hashedin.hu22.service;

import com.hashedin.hu22.controllers.status;
import com.hashedin.hu22.entities.User;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserService {

    User saveUser(User user);
    List<User> getAllUsers();
    User getUserByMobile(String mobile);
    User updateUser(User user,String mobile);
    status userLogin(User user);
}
