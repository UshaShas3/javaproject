package com.hashedin.hu22;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class Hu22Application extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(Hu22Application.class, args);
	}

}

