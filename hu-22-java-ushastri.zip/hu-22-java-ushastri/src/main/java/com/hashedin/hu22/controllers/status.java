package com.hashedin.hu22.controllers;

import com.sun.net.httpserver.Authenticator;

public enum status {
    Success,
    Failure
}
