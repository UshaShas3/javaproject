package com.hashedin.hu22.service.impl;

import com.hashedin.hu22.entities.Movie;
import com.hashedin.hu22.exception.ResourceNotFoundException;
import com.hashedin.hu22.repositories.MovieRepository;
import com.hashedin.hu22.service.MovieService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieServiceImpl implements MovieService {

    private MovieRepository movieRepository;

    public MovieServiceImpl(MovieRepository movieRepository) {
        this.movieRepository = movieRepository;
    }

    @Override
    public Movie saveMovie(Movie movie) {
        return movieRepository.save(movie);
    }

    @Override
    public List<Movie> getAllMovies() {
        return movieRepository.findAll();
    }

    @Override
    public Movie getMovieByName(String movieName) {
        return movieRepository.findById(movieName).orElseThrow(()->new ResourceNotFoundException("Movie","movieName","movieName"));
    }

    @Override
    public Movie updateMovie(Movie movie, String movieName) {

        //check if user is present in database or not
        Movie existingMovie = movieRepository.findById(movieName).orElseThrow(
                ()->new ResourceNotFoundException("Movie","movieName","movieName"));

        existingMovie.setDuration(movie.getDuration());
        existingMovie.setGenre(movie.getGenre());
        existingMovie.setCast(movie.getCast());
        existingMovie.setDescription(movie.getDescription());
        existingMovie.setDirector(movie.getDirector());
        existingMovie.setLanguage(movie.getLanguage());
        existingMovie.setProducer(movie.getProducer());
        existingMovie.setShowTimings(movie.getShowTimings());
        existingMovie.setTheatre(movie.getTheatre());

        //save to database
        return movieRepository.save(existingMovie);
    }

}
