package com.hashedin.hu22;

import com.hashedin.hu22.entities.Demo;
import com.hashedin.hu22.entities.User;
import com.hashedin.hu22.repositories.DemoRepository;
import org.junit.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

@SpringBootTest

public class Hu22ApplicationTests {

    @Test
    public void testGetUser() {
       RestTemplate restTemplate = new RestTemplate();
       User user = restTemplate.getForObject("http://localhost:8080/user/8357487945",User.class);
       assertNotNull(user);
       assertEquals("suryachandra@gmail.com",user.getEmail());
   }

   @Test
    public void testCreateUser() {
        RestTemplate restTemplate = new RestTemplate();
        User user = new User();
        user.setMobile("5555522222");
        user.setDob("01012000");
        user.setFname("myntra");
        user.setLname("netflix");
        user.setEmail("myntranetflix@gmail.com");
        user.setPrefLocation("Kerala");
        user.setPrefGenre("Suspense");
        user.setRole("Customer");
        User newUser = restTemplate.postForObject("http://localhost:8080/user/",user,User.class);
        assertNotNull(newUser);
        assertNotNull(newUser.getMobile());
        assertEquals("amazon",newUser.getLname());
    }

    @Test
    public void testUpdateUser() {
        RestTemplate restTemplate = new RestTemplate();
        User user = restTemplate.getForObject("http://localhost:8080/user/9876533455",User.class);
        user.setLname("Kumar B V M");
        restTemplate.put("http://localhost:8080/user/9876533455",user);
    }
}
